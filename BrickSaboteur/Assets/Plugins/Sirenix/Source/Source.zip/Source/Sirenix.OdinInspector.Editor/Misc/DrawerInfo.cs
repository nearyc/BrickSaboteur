#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="DrawerInfo.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// <copyright file="DrawerInfo.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Sirenix.OdinInspector.Editor
{
    using System;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    [Obsolete("The old DrawerLocator class and its peripheral types are now obsolete. Use DrawerUtilities and the new DrawerChain system instead.", true)]
    public class DrawerInfo
    {
    }
}
#endif